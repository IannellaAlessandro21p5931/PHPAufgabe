<?php

class Contact extends Controller {

    public function index() {
        
        echo 'Contact Index';
    }
}