<form action="PHPAufgabe/bzt.m120.mvc-example-master/public/home/newsletter" method="POST">
    E-mail:<br>
	<input name="mail" type="text" /><br /> <br/>

	<button type="submit" value="Submit">Submit</button>
</form>